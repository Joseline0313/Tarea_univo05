<?php

namespace App\Controllers;

class Galery extends BaseController
{
    public function index()
    {
        return view('galery/index');
    }
}